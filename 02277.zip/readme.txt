02277.exe 

gdi malware

made in c++

by Hugopako

Among ssssssss u           u ssssssss #
            s               u           u s               #
            ssssssss u           u ssssssss #
                          s u           u               s
             ssssssss uuuuuuu ssssssss #